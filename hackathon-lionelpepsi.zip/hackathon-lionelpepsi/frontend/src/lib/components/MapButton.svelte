<script>
  import { onMount } from 'svelte';
  import { fly, scale } from 'svelte/transition';
  import { cubicOut } from 'svelte/easing';

  let isExpanded = false;
  let mapImage = '/map.png';

  function toggleMap() {
    isExpanded = !isExpanded;
  }

  function closeMap() {
    isExpanded = false;
  }
</script>

<!-- Map Button (Fixed Bottom Right) -->
<button
  on:click={toggleMap}
  class="fixed bottom-6 right-6 z-50 w-16 h-16 bg-[#c4a574] hover:bg-[#d4b584] rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-[#c4a574] focus:ring-offset-2"
  aria-label="Xem bản đồ"
  title="Xem bản đồ"
>
  <svg class="w-8 h-8 text-[#1a1a1a]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
  </svg>
</button>

<!-- Expanded Map Modal -->
{#if isExpanded}
  <div
    class="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
    on:click={closeMap}
    transition:fade={{ duration: 200 }}
  >
    <div
      class="relative max-w-4xl w-full max-h-[90vh] bg-[#2a2a2a] rounded-2xl shadow-2xl overflow-hidden"
      on:click|stopPropagation
      transition:scale={{ duration: 300, easing: cubicOut }}
    >
      <!-- Close Button -->
      <button
        on:click={closeMap}
        class="absolute top-4 right-4 z-10 w-10 h-10 bg-[#c4a574] hover:bg-[#d4b584] rounded-full flex items-center justify-center transition-all duration-200 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-[#c4a574]"
        aria-label="Đóng bản đồ"
      >
        <svg class="w-6 h-6 text-[#1a1a1a]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>

      <!-- Map Image -->
      <div class="p-6">
        <h2 class="text-2xl font-bold text-[#c4a574] mb-4 text-center">Bản Đồ Bảo Tàng</h2>
        <div class="bg-white rounded-lg p-4 flex items-center justify-center">
          <img
            src={mapImage}
            alt="Bản đồ bảo tàng"
            class="max-w-full max-h-[70vh] object-contain rounded-lg"
          />
        </div>
      </div>
    </div>
  </div>
{/if}

<style>
  @keyframes fade {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
</style>

