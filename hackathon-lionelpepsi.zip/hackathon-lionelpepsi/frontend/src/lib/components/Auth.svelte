<script>
  import { register } from '$lib/api';
  import { login } from '$lib/api';
  import { goto } from '$app/navigation';
  import { fade, fly } from 'svelte/transition';

  let showLogin = false;

  let error = '';
  let success = '';
  let loading = false;

  let username = '';
  let password = '';
  let message = '';
  let showPassword = false;

  async function handleRegister() {
    if (loading) return;
    loading = true;
    error = '';
    success = '';
    
    try {
      const res = await register(username, password);
      message = res.message;
      if (res.message === 'Registered successfully!') {
        success = "Đăng ký thành công! Vui lòng đăng nhập.";
        setTimeout(() => {
          showLogin = true;
          success = '';
        }, 1500);
      } else {
        error = res.error || "Đăng ký thất bại";
      }
    } catch (err) {
      error = "Không thể kết nối với server";
    } finally {
      loading = false;
    }
  }

  async function handleLogin() {
    if (loading) return;
    loading = true;
    error = '';
    success = '';
    
    try {
      const res = await login(username, password);
      message = res.message;
      if (res.isLoggedIn) {
        success = "Đăng nhập thành công!";
        setTimeout(() => {
          location.reload();
        }, 500);
      } else {
        error = res.error || "Sai tài khoản hoặc mật khẩu";
      }
    } catch (err) {
      error = "Không thể kết nối với server";
    } finally {
      loading = false;
    }
  }
</script>

<div class="w-full max-w-md mx-auto">
  {#if !showLogin}
    <!-- Register Form -->
    <div transition:fade={{ duration: 300 }}>
      <div class="text-center mb-6">
        <h2 class="text-3xl font-bold text-[#c4a574] mb-2">Đăng Ký</h2>
        <p class="text-gray-400 text-sm">Tạo tài khoản mới để bắt đầu</p>
      </div>

      {#if error}
        <div class="mb-4 bg-red-500/20 border border-red-500 text-red-400 px-4 py-3 rounded-lg animate-shake" transition:fly={{ y: -10 }}>
          ⚠️ {error}
        </div>
      {/if}

      {#if success}
        <div class="mb-4 bg-green-500/20 border border-green-500 text-green-400 px-4 py-3 rounded-lg" transition:fly={{ y: -10 }}>
          ✅ {success}
        </div>
      {/if}

      <form on:submit|preventDefault={handleRegister} class="space-y-5">
        <div>
          <label class="block text-gray-300 text-sm font-semibold mb-2">Tên đăng nhập</label>
          <input
            type="text"
            bind:value={username}
            placeholder="Nhập tên đăng nhập"
            class="w-full px-4 py-3 bg-[#1a1a1a] border-2 border-[#4a4a4a] text-white rounded-lg focus:border-[#c4a574] focus:ring-2 focus:ring-[#c4a574]/50 focus:outline-none transition-all duration-300"
            required
            disabled={loading}
          />
        </div>

        <div>
          <label class="block text-gray-300 text-sm font-semibold mb-2">Mật khẩu</label>
          <div class="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              bind:value={password}
              placeholder="Nhập mật khẩu"
              class="w-full px-4 py-3 bg-[#1a1a1a] border-2 border-[#4a4a4a] text-white rounded-lg focus:border-[#c4a574] focus:ring-2 focus:ring-[#c4a574]/50 focus:outline-none transition-all duration-300 pr-12"
              required
              disabled={loading}
            />
            <button
              type="button"
              on:click={() => showPassword = !showPassword}
              class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#c4a574] transition-colors"
            >
              {#if showPassword}
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                </svg>
              {:else}
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              {/if}
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          class="w-full bg-gradient-to-r from-[#c4a574] to-[#d4b584] hover:from-[#d4b584] hover:to-[#c4a574] text-[#1a1a1a] font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {#if loading}
            <span class="flex items-center justify-center gap-2">
              <div class="w-5 h-5 border-2 border-[#1a1a1a] border-t-transparent rounded-full animate-spin"></div>
              Đang xử lý...
            </span>
          {:else}
            📝 Đăng Ký
          {/if}
        </button>
      </form>

      <div class="mt-6 text-center">
        <p class="text-gray-400 text-sm">
          Đã có tài khoản?
          <button
            on:click={() => { showLogin = true; error = ''; success = ''; }}
            class="text-[#c4a574] hover:text-[#d4b584] font-semibold ml-1 transition-colors"
          >
            Đăng nhập ngay
          </button>
        </p>
      </div>
    </div>
  {:else}
    <!-- Login Form -->
    <div transition:fade={{ duration: 300 }}>
      <div class="text-center mb-6">
        <h2 class="text-3xl font-bold text-[#c4a574] mb-2">Đăng Nhập</h2>
        <p class="text-gray-400 text-sm">Chào mừng bạn trở lại</p>
      </div>

      {#if error}
        <div class="mb-4 bg-red-500/20 border border-red-500 text-red-400 px-4 py-3 rounded-lg animate-shake" transition:fly={{ y: -10 }}>
          ⚠️ {error}
        </div>
      {/if}

      {#if success}
        <div class="mb-4 bg-green-500/20 border border-green-500 text-green-400 px-4 py-3 rounded-lg" transition:fly={{ y: -10 }}>
          ✅ {success}
        </div>
      {/if}

      <form on:submit|preventDefault={handleLogin} class="space-y-5">
        <div>
          <label class="block text-gray-300 text-sm font-semibold mb-2">Tên đăng nhập</label>
          <input
            type="text"
            bind:value={username}
            placeholder="Nhập tên đăng nhập"
            class="w-full px-4 py-3 bg-[#1a1a1a] border-2 border-[#4a4a4a] text-white rounded-lg focus:border-[#c4a574] focus:ring-2 focus:ring-[#c4a574]/50 focus:outline-none transition-all duration-300"
            required
            disabled={loading}
          />
        </div>

        <div>
          <label class="block text-gray-300 text-sm font-semibold mb-2">Mật khẩu</label>
          <div class="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              bind:value={password}
              placeholder="Nhập mật khẩu"
              class="w-full px-4 py-3 bg-[#1a1a1a] border-2 border-[#4a4a4a] text-white rounded-lg focus:border-[#c4a574] focus:ring-2 focus:ring-[#c4a574]/50 focus:outline-none transition-all duration-300 pr-12"
              required
              disabled={loading}
            />
            <button
              type="button"
              on:click={() => showPassword = !showPassword}
              class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#c4a574] transition-colors"
            >
              {#if showPassword}
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                </svg>
              {:else}
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              {/if}
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          class="w-full bg-gradient-to-r from-[#c4a574] to-[#d4b584] hover:from-[#d4b584] hover:to-[#c4a574] text-[#1a1a1a] font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {#if loading}
            <span class="flex items-center justify-center gap-2">
              <div class="w-5 h-5 border-2 border-[#1a1a1a] border-t-transparent rounded-full animate-spin"></div>
              Đang xử lý...
            </span>
          {:else}
            🔐 Đăng Nhập
          {/if}
        </button>
      </form>

      <div class="mt-6 text-center">
        <p class="text-gray-400 text-sm">
          Chưa có tài khoản?
          <button
            on:click={() => { showLogin = false; error = ''; success = ''; }}
            class="text-[#c4a574] hover:text-[#d4b584] font-semibold ml-1 transition-colors"
          >
            Đăng ký ngay
          </button>
        </p>
      </div>
    </div>
  {/if}
</div>

<style>
  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
  }

  .animate-shake {
    animation: shake 0.4s ease-in-out;
  }
</style>
