<script>
	import '../app.css';
	import { chosenOption, ensureData } from '$lib/stores/ChosenOption.js';
	import { onMount } from 'svelte';
	import { get } from 'svelte/store';
	import favicon from '$lib/assets/favicon.svg';
	import Header from '$lib/components/Header.svelte';
	import Footer from '$lib/components/Footer.svelte';
	import MapButton from '$lib/components/MapButton.svelte';

	let showOptionModal = false;

	onMount(async () => {
		if (!get(chosenOption)) {
		showOptionModal = true;
		} else {
		await ensureData(get(chosenOption));
		}
	});

</script>

<svelte:head>
	<link rel="icon" href={favicon} />
</svelte:head>

<Header />
<slot />
<Footer />
<MapButton />
