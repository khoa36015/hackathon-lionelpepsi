1. Sau khi clone|pull chạy các lệnh Terminal sau:
- npm i
- npm i -D tailwindcss postcss autoprefixer
- npm audit fix

2. Chạy Frontend trên Local:
- Kiểm tra thư mục node_modules đã tồn tại ? bước tiếp theo : Quay lại 1.
- npm run dev
- [Nếu lỗi chạy lệnh npx sv add devtools-json và npm i @tailwind/postcss]